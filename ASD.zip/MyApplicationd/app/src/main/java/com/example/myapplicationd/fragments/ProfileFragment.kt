package com.example.myapplicationd.fragments

import androidx.fragment.app.Fragment
import com.example.myapplicationd.R

class ProfileFragment : Fragment(R.layout.fragment_profile) {
}